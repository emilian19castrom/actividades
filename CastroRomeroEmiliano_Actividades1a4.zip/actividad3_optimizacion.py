import math
import random

# Función Objetivo (Minimización)
def funcion_costo(x):
    return x**2 - 4*x + 4  # Mínimo global en x = 2 (costo = 0)

# 1. Hill Climbing
def hill_climbing(inicio, paso=0.1, max_iter=100):
    actual = inicio
    costo_actual = funcion_costo(actual)
    
    for i in range(max_iter):
        vecino = actual + random.choice([-paso, paso])
        costo_vecino = funcion_costo(vecino)
        
        if costo_vecino < costo_actual:
            actual = vecino
            costo_actual = costo_vecino
            
    return actual, costo_actual

# 2. Simulated Annealing
def simulated_annealing(inicio, temp_inicial=100.0, enfriamiento=0.95, max_iter=100):
    actual = inicio
    costo_actual = funcion_costo(actual)
    temp = temp_inicial
    
    for i in range(max_iter):
        vecino = actual + random.uniform(-1, 1)
        costo_vecino = funcion_costo(vecino)
        delta = costo_vecino - costo_actual
        
        if delta < 0 or random.random() < math.exp(-delta / temp):
            actual = vecino
            costo_actual = costo_vecino
            
        temp *= enfriamiento
        
    return actual, costo_actual

if __name__ == "__main__":
    x0 = 10.0
    sol_hc, costo_hc = hill_climbing(x0)
    sol_sa, costo_sa = simulated_annealing(x0)
    
    print(f"Hill Climbing - Solución: x = {sol_hc:.4f}, Costo: {costo_hc:.4f}")
    print(f"Simulated Annealing - Solución: x = {sol_sa:.4f}, Costo: {costo_sa:.4f}")
