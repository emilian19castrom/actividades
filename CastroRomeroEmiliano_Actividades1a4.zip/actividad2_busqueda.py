import networkx as nx
import matplotlib.pyplot as plt

# ---------------------------------------------------------
# PROBLEMA 1: Ruta entre Almacenes y Centros de Distribución
# ---------------------------------------------------------
G1 = nx.DiGraph()
G1.add_edge('Almacen_Central', 'Nodo_A', weight=12)
G1.add_edge('Almacen_Central', 'Nodo_B', weight=8)
G1.add_edge('Nodo_A', 'Centro_Dist_1', weight=15)
G1.add_edge('Nodo_B', 'Centro_Dist_1', weight=5)
G1.add_edge('Nodo_B', 'Centro_Dist_2', weight=20)
G1.add_edge('Centro_Dist_1', 'Cliente_Final', weight=10)
G1.add_edge('Centro_Dist_2', 'Cliente_Final', weight=4)

print("--- PROBLEMA 1: GRAFO DE DISTRIBUCIÓN LOGÍSTICA ---")
print(f"Nodos (Estados): {list(G1.nodes())}")
print(f"Aristas (Acciones y Costos): {list(G1.edges(data=True))}")

# ---------------------------------------------------------
# PROBLEMA 2: Sistema de Micro red Eléctrica Inteligente
# ---------------------------------------------------------
G2 = nx.Graph()
G2.add_edge('Subestacion', 'Transformador_1', weight=100)
G2.add_edge('Subestacion', 'Transformador_2', weight=150)
G2.add_edge('Transformador_1', 'Zona_Residencial', weight=50)
G2.add_edge('Transformador_2', 'Zona_Industrial', weight=200)

print("\n--- PROBLEMA 2: GRAFO DE RED ELÉCTRICA ---")
print(f"Nodos: {list(G2.nodes())}")
print(f"Aristas: {list(G2.edges(data=True))}")
