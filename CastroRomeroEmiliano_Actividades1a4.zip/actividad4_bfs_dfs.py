from collections import deque
import time

# Representación del Laberinto como Grafo (Adyacencia)
grafo_laberinto = {
    'Entrada': ['A', 'B'],
    'A': ['Entrada', 'C', 'D'],
    'B': ['Entrada', 'E'],
    'C': ['A'],
    'D': ['A', 'Salida'],
    'E': ['B'],
    'Salida': ['D']
}

def bfs(grafo, inicio, meta):
    tiempo_inicio = time.time()
    cola = deque([[inicio]])
    visitados = set()
    nodos_expandidos = 0
    
    while cola:
        camino = cola.popleft()
        nodo = camino[-1]
        nodos_expandidos += 1
        
        if nodo == meta:
            tiempo_fin = time.time()
            return camino, nodos_expandidos, (tiempo_fin - tiempo_inicio) * 1000
            
        if nodo not in visitados:
            visitados.add(nodo)
            for vecino in grafo.get(nodo, []):
                nuevo_camino = list(camino)
                nuevo_camino.append(vecino)
                cola.append(nuevo_camino)
                
    return None, nodos_expandidos, 0

def dfs(grafo, inicio, meta):
    tiempo_inicio = time.time()
    pila = [[inicio]]
    visitados = set()
    nodos_expandidos = 0
    
    while pila:
        camino = pila.pop()
        nodo = camino[-1]
        nodos_expandidos += 1
        
        if nodo == meta:
            tiempo_fin = time.time()
            return camino, nodos_expandidos, (tiempo_fin - tiempo_inicio) * 1000
            
        if nodo not in visitados:
            visitados.add(nodo)
            for vecino in grafo.get(nodo, []):
                nuevo_camino = list(camino)
                nuevo_camino.append(vecino)
                pila.append(nuevo_camino)
                
    return None, nodos_expandidos, 0

if __name__ == "__main__":
    camino_bfs, exp_bfs, t_bfs = bfs(grafo_laberinto, 'Entrada', 'Salida')
    camino_dfs, exp_dfs, t_dfs = dfs(grafo_laberinto, 'Entrada', 'Salida')
    
    print("--- RESULTADOS DE BÚSQUEDA ---")
    print(f"BFS -> Camino: {camino_bfs} | Nodos Expandidos: {exp_bfs} | Tiempo: {t_bfs:.4f} ms")
    print(f"DFS -> Camino: {camino_dfs} | Nodos Expandidos: {exp_dfs} | Tiempo: {t_dfs:.4f} ms")
